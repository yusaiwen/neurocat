.. currentmodule:: neurocat


API Reference
:mod:`neurocat.plotting` - Plot brain
