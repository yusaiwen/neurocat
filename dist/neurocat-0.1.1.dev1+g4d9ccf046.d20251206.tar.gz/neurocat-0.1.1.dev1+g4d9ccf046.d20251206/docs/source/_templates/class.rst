{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :no-inherited-members:

.. raw:: html

    <div style='clear:both'></div>
