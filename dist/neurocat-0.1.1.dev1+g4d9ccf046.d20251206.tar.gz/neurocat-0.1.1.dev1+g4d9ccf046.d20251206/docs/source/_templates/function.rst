{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. .. include:: modules/{{ module }}.{{ objname }}.examples

.. raw:: html

    <div style='clear:both'></div>
