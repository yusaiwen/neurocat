﻿neurocat.plotting.draw_subcortex_tian
=====================================

.. currentmodule:: neurocat.plotting

.. autofunction:: draw_subcortex_tian

.. .. include:: modules/neurocat.plotting.draw_subcortex_tian.examples

.. raw:: html

    <div style='clear:both'></div>