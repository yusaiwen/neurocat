﻿neurocat.color
==============

.. currentmodule:: neurocat.color

.. autofunction:: neurocat.color

.. .. include:: modules/neurocat.color.neurocat.color.examples

.. raw:: html

    <div style='clear:both'></div>