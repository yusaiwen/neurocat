﻿neurocat.plotting.draw_and_save_hm
==================================

.. currentmodule:: neurocat.plotting

.. autofunction:: draw_and_save_hm

.. .. include:: modules/neurocat.plotting.draw_and_save_hm.examples

.. raw:: html

    <div style='clear:both'></div>