﻿neurocat.util.logger
====================

.. currentmodule:: neurocat.util

.. autofunction:: logger

.. .. include:: modules/neurocat.util.logger.examples

.. raw:: html

    <div style='clear:both'></div>