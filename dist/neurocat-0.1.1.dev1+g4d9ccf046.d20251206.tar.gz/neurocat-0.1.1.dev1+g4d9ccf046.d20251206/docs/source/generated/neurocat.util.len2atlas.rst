﻿neurocat.util.len2atlas
=======================

.. currentmodule:: neurocat.util

.. autofunction:: len2atlas

.. .. include:: modules/neurocat.util.len2atlas.examples

.. raw:: html

    <div style='clear:both'></div>