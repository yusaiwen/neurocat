﻿neurocat.plotting.draw_and_save
===============================

.. currentmodule:: neurocat.plotting

.. autofunction:: draw_and_save

.. .. include:: modules/neurocat.plotting.draw_and_save.examples

.. raw:: html

    <div style='clear:both'></div>