﻿neurocat.util.gen_gii_hm
========================

.. currentmodule:: neurocat.util

.. autofunction:: gen_gii_hm

.. .. include:: modules/neurocat.util.gen_gii_hm.examples

.. raw:: html

    <div style='clear:both'></div>