﻿neurocat.util.get_cii_gii_data
==============================

.. currentmodule:: neurocat.util

.. autofunction:: get_cii_gii_data

.. .. include:: modules/neurocat.util.get_cii_gii_data.examples

.. raw:: html

    <div style='clear:both'></div>