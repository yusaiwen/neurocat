neurocat.plotting.BrainPlotter
==============================

.. currentmodule:: neurocat.plotting

.. autoclass:: BrainPlotter