﻿neurocat.color.get_color_gradient
=================================

.. currentmodule:: neurocat.color

.. autofunction:: get_color_gradient

.. .. include:: modules/neurocat.color.get_color_gradient.examples

.. raw:: html

    <div style='clear:both'></div>