﻿neurocat.io.save_cii_tm
=======================

.. currentmodule:: neurocat.io

.. autofunction:: save_cii_tm

.. .. include:: modules/neurocat.io.save_cii_tm.examples

.. raw:: html

    <div style='clear:both'></div>