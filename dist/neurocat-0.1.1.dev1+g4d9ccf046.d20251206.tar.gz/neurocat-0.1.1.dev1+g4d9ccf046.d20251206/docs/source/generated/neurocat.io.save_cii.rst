﻿neurocat.io.save_cii
====================

.. currentmodule:: neurocat.io

.. autofunction:: save_cii

.. .. include:: modules/neurocat.io.save_cii.examples

.. raw:: html

    <div style='clear:both'></div>