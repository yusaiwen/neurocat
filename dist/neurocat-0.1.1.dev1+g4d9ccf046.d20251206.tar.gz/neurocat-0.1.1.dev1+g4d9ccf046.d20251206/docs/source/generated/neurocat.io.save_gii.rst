﻿neurocat.io.save_gii
====================

.. currentmodule:: neurocat.io

.. autofunction:: save_gii

.. .. include:: modules/neurocat.io.save_gii.examples

.. raw:: html

    <div style='clear:both'></div>