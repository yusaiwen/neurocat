﻿neurocat.util.remove_mw
=======================

.. currentmodule:: neurocat.util

.. autofunction:: remove_mw

.. .. include:: modules/neurocat.util.remove_mw.examples

.. raw:: html

    <div style='clear:both'></div>