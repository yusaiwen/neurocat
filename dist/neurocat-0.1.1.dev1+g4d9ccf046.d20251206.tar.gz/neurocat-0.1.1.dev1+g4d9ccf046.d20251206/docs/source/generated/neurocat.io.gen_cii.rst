﻿neurocat.io.gen_cii
===================

.. currentmodule:: neurocat.io

.. autofunction:: gen_cii

.. .. include:: modules/neurocat.io.gen_cii.examples

.. raw:: html

    <div style='clear:both'></div>