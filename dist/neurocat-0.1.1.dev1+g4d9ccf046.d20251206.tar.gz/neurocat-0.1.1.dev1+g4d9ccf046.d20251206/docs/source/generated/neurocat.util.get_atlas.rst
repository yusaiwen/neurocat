﻿neurocat.util.get_atlas
=======================

.. currentmodule:: neurocat.util

.. autofunction:: get_atlas

.. .. include:: modules/neurocat.util.get_atlas.examples

.. raw:: html

    <div style='clear:both'></div>