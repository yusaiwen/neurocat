﻿neurocat.util.tmp_name
======================

.. currentmodule:: neurocat.util

.. autofunction:: tmp_name

.. .. include:: modules/neurocat.util.tmp_name.examples

.. raw:: html

    <div style='clear:both'></div>