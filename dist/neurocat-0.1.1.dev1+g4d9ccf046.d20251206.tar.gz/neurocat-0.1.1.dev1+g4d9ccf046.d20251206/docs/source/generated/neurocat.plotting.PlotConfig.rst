neurocat.plotting.PlotConfig
============================

.. currentmodule:: neurocat.plotting

.. autoclass:: PlotConfig