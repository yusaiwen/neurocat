﻿neurocat.util.gen_gii
=====================

.. currentmodule:: neurocat.util

.. autofunction:: gen_gii

.. .. include:: modules/neurocat.util.gen_gii.examples

.. raw:: html

    <div style='clear:both'></div>