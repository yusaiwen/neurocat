﻿neurocat.color.get_cm
=====================

.. currentmodule:: neurocat.color

.. autofunction:: get_cm

.. .. include:: modules/neurocat.color.get_cm.examples

.. raw:: html

    <div style='clear:both'></div>