﻿neurocat.util
=============

.. currentmodule:: neurocat

.. autofunction:: util

.. .. include:: modules/neurocat.util.examples

.. raw:: html

    <div style='clear:both'></div>