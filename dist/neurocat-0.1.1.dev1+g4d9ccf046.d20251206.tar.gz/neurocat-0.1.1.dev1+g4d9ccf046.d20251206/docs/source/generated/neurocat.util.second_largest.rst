﻿neurocat.util.second_largest
============================

.. currentmodule:: neurocat.util

.. autofunction:: second_largest

.. .. include:: modules/neurocat.util.second_largest.examples

.. raw:: html

    <div style='clear:both'></div>