﻿neurocat.util.reverse_mw
========================

.. currentmodule:: neurocat.util

.. autofunction:: reverse_mw

.. .. include:: modules/neurocat.util.reverse_mw.examples

.. raw:: html

    <div style='clear:both'></div>