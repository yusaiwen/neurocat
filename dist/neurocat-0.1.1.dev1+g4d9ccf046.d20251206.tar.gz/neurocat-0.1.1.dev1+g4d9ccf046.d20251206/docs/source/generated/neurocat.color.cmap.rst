neurocat.color.cmap
===================

.. currentmodule:: neurocat.color

.. autoclass:: cmap