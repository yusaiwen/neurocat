﻿neurocat.plotting.draw_sftian_save
==================================

.. currentmodule:: neurocat.plotting

.. autofunction:: draw_sftian_save

.. .. include:: modules/neurocat.plotting.draw_sftian_save.examples

.. raw:: html

    <div style='clear:both'></div>