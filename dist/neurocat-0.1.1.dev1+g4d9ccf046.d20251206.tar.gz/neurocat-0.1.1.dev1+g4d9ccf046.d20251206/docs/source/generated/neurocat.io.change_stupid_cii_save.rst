﻿neurocat.io.change_stupid_cii_save
==================================

.. currentmodule:: neurocat.io

.. autofunction:: change_stupid_cii_save

.. .. include:: modules/neurocat.io.change_stupid_cii_save.examples

.. raw:: html

    <div style='clear:both'></div>