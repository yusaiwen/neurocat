﻿neurocat.color.hex_to_RGB
=========================

.. currentmodule:: neurocat.color

.. autofunction:: hex_to_RGB

.. .. include:: modules/neurocat.color.hex_to_RGB.examples

.. raw:: html

    <div style='clear:both'></div>