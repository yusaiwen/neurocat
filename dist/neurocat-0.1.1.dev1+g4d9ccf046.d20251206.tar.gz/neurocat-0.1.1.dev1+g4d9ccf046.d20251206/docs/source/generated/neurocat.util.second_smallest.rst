﻿neurocat.util.second_smallest
=============================

.. currentmodule:: neurocat.util

.. autofunction:: second_smallest

.. .. include:: modules/neurocat.util.second_smallest.examples

.. raw:: html

    <div style='clear:both'></div>