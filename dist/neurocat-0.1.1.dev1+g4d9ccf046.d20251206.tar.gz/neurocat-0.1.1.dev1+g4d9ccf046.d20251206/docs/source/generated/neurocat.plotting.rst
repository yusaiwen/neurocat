﻿neurocat.plotting
=================

.. currentmodule:: neurocat.plotting

.. autofunction:: neurocat.plotting

.. .. include:: modules/neurocat.plotting.neurocat.plotting.examples

.. raw:: html

    <div style='clear:both'></div>