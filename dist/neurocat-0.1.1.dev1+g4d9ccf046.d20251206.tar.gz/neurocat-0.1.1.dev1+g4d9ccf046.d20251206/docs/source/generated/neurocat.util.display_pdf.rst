﻿neurocat.util.display_pdf
=========================

.. currentmodule:: neurocat.util

.. autofunction:: display_pdf

.. .. include:: modules/neurocat.util.display_pdf.examples

.. raw:: html

    <div style='clear:both'></div>