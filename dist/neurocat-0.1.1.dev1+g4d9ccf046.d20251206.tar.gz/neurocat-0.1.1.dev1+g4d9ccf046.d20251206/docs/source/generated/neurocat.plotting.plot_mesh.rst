﻿neurocat.plotting.plot_mesh
===========================

.. currentmodule:: neurocat.plotting

.. autofunction:: plot_mesh

.. .. include:: modules/neurocat.plotting.plot_mesh.examples

.. raw:: html

    <div style='clear:both'></div>