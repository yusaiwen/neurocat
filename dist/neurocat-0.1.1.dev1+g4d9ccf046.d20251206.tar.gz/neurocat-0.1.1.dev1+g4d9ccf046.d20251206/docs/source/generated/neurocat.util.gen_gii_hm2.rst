﻿neurocat.util.gen_gii_hm2
=========================

.. currentmodule:: neurocat.util

.. autofunction:: gen_gii_hm2

.. .. include:: modules/neurocat.util.gen_gii_hm2.examples

.. raw:: html

    <div style='clear:both'></div>