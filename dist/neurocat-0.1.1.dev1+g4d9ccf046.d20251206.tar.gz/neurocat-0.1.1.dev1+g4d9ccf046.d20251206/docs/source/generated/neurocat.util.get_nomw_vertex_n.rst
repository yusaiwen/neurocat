﻿neurocat.util.get_nomw_vertex_n
===============================

.. currentmodule:: neurocat.util

.. autofunction:: get_nomw_vertex_n

.. .. include:: modules/neurocat.util.get_nomw_vertex_n.examples

.. raw:: html

    <div style='clear:both'></div>