﻿neurocat.util.display_pdf2
==========================

.. currentmodule:: neurocat.util

.. autofunction:: display_pdf2

.. .. include:: modules/neurocat.util.display_pdf2.examples

.. raw:: html

    <div style='clear:both'></div>