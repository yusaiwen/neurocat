﻿neurocat.util.thresh_array
==========================

.. currentmodule:: neurocat.util

.. autofunction:: thresh_array

.. .. include:: modules/neurocat.util.thresh_array.examples

.. raw:: html

    <div style='clear:both'></div>