﻿neurocat.color.get_transparent_cm
=================================

.. currentmodule:: neurocat.color

.. autofunction:: get_transparent_cm

.. .. include:: modules/neurocat.color.get_transparent_cm.examples

.. raw:: html

    <div style='clear:both'></div>